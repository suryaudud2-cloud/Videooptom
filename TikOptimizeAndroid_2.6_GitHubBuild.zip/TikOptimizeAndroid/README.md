# TikOptimize Android 2.6

Project Android yang bisa dibuat menjadi APK tanpa Android Studio menggunakan GitHub Actions.

## Cara membuat APK langsung dari browser/HP
1. Buat repository baru di GitHub.
2. Upload seluruh isi folder project ini ke repository.
3. Pastikan branch bernama `main`.
4. Buka tab **Actions**.
5. Pilih workflow **Build TikOptimize APK**.
6. Jalankan **Run workflow** atau push perubahan.
7. Setelah selesai, buka hasil workflow dan download artifact **TikOptimize-debug-apk**.
8. Ekstrak ZIP artifact dan install `app-debug.apk` di Android/Xiaomi.

## Fungsi Android
- Memakai UI HTML TikOptimize yang diberikan.
- Pemrosesan video di Android memakai Media3 Transformer untuk transcoding H.264 + AAC.
- Pemilihan video memakai Android file picker.
- Hasil dapat disimpan ke `Movies/TikOptimize`.
- Hasil dapat dibagikan melalui Android Share Sheet.
- Tidak melakukan spoofing identitas iPhone.

## Catatan
Preset UI tetap mengikuti file HTML sumber. Engine native saat ini fokus pada transcoding H.264/AAC. Pengaturan bitrate/resolusi lanjutan belum semuanya diterapkan ke native Transformer.
