# TikOptimize does not require custom ProGuard rules.
