package com.tikoptimize.app

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.webkit.*
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.annotation.OptIn
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Transformer
import androidx.media3.transformer.ExportException
import java.io.File

class MainActivity : AppCompatActivity() {
    private lateinit var web: WebView
    private var selectedUri: Uri? = null
    private var outputFile: File? = null
    private var fileChooserCallback: ValueCallback<Array<Uri>>? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        web = findViewById(R.id.webview)
        configureWebView()
    }

    private fun configureWebView() {
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.allowFileAccess = true
        web.settings.allowContentAccess = true
        web.settings.mediaPlaybackRequiresUserGesture = false
        web.addJavascriptInterface(AndroidBridge(), "AndroidBridge")
        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(view: WebView?, callback: ValueCallback<Array<Uri>>?, params: FileChooserParams?): Boolean {
                fileChooserCallback?.onReceiveValue(null)
                fileChooserCallback = callback
                val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "video/*"
                    putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)
                }
                startActivityForResult(intent, 1001)
                return true
            }
        }
        web.webViewClient = WebViewClient()
        web.loadUrl("file:///android_asset/index.html")
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001) {
            val uri = if (resultCode == Activity.RESULT_OK) data?.data else null
            selectedUri = uri
            fileChooserCallback?.onReceiveValue(uri?.let { arrayOf(it) })
            fileChooserCallback = null
        }
    }

    inner class AndroidBridge {
        @JavascriptInterface fun startNativeEncoding() {
            val uri = selectedUri
            if (uri == null) { runOnUiThread { toast("Pilih video terlebih dahulu") }; return }
            runOnUiThread { web.evaluateJavascript("window.nativeEncodingStarted && window.nativeEncodingStarted()", null) }
            val out = File(cacheDir, "TikOptimize_${System.currentTimeMillis()}.mp4")
            outputFile = out
            val edited = EditedMediaItem.Builder(MediaItem.fromUri(uri)).build()
            val transformer = Transformer.Builder(this@MainActivity)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: Transformer.ExportResult) {
                        runOnUiThread {
                            web.evaluateJavascript("window.nativeEncodingFinished(${jsonQuote(out.absolutePath)})", null)
                        }
                    }
                    override fun onError(composition: Composition, exportResult: Transformer.ExportResult, exportException: ExportException) {
                        runOnUiThread {
                            web.evaluateJavascript("window.nativeEncodingError(${jsonQuote(exportException.message ?: "Encoding gagal")})", null)
                        }
                    }
                }).build()
            Thread { transformer.start(edited, out.absolutePath) }.start()
        }

        @JavascriptInterface fun getResultUri(): String? = outputFile?.let { Uri.fromFile(it).toString() }

        @JavascriptInterface fun saveToGallery(): Boolean {
            val file = outputFile ?: return false
            return try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "${file.nameWithoutExtension}_TikOptimized.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/TikOptimize")
                }
                val resolver = contentResolver
                val uri = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return false
                resolver.openOutputStream(uri)?.use { out -> file.inputStream().use { it.copyTo(out) } }
                runOnUiThread { toast("Video disimpan ke Movies/TikOptimize") }
                true
            } catch (e: Exception) { false }
        }

        @JavascriptInterface fun shareResult() {
            val file = outputFile ?: return
            val uri = androidx.core.content.FileProvider.getUriForFile(this@MainActivity, "com.tikoptimize.app.fileprovider", file)
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "video/mp4"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Bagikan Video"))
        }
    }

    private fun jsonQuote(s: String): String = org.json.JSONObject.quote(s)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
